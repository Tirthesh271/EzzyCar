from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def hello_world():
    import pymysql
    import re

    host = 'localhost'
    user = 'root'
    password = 'Rajgad@12'
    db = 'ezzycar'

    try:
        con = pymysql.connect(host=host, user=user, password=password, db=db, use_unicode=True, charset='utf8')
        print('+=========================+')
        print('|  CONNECTED TO DATABASE  |')
        print('+=========================+')
    except Exception as e:
        print("error")
    cur = con.cursor()
    cur.execute("SELECT * FROM carspecification ")
    data = cur.fetchall()
    print(data)
    
    for row in data:
        id_berita = row[0]
        judul = row[1]
        isi = row[2]
        print('===============================================')
        print('BERITA KE', id_berita)
        print('Judul :', judul)
        print('Isi   :', isi)
        print('===============================================')


    return render_template('index.html')
if __name__ == '__main__':
   app.run()
